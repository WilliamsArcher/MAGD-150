let crazy = [];

function setup() {
  createCanvas(400, 400);
  background(220);
 }
   
function mouseClicked() 
{
    for (let i = 0; i < 10; i++)
  {
   crazy[i] = i * 5;
  }
}

function draw() 
{
background(0);
 
for (let i = 0; i < crazy.length; i++) 
{
crazy[i] += 7; 
square(crazy[i], mouseY, 10);
console.log(crazy);
}
}