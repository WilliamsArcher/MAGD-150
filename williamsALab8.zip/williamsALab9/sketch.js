let snowman;
let tree;

function preload() {

  snowman = loadImage("assets/Snowman.png");
  tree = loadImage("assets/Tree.jpg");

}

function setup() {
  createCanvas(500, 500);
}

function draw() {

  background(180, 220, 255);

  fill(255);
  noStroke();
  rect(0, 400, width, 100);

  image(tree, 25, 25, 450, 450);

  let scaleAmount = map(mouseX, 0, width, 0.5, 2);

  push();
  translate(350, 300);
  scale(scaleAmount);

  image(snowman, -100, -100, 100, 150);

  pop();

  textFont('Arial');

  fill(255, 0, 0);
  stroke(255);
  strokeWeight(2);
  text(
    "Move your mouse left and right!",
    40, 30, 420,100 );

}