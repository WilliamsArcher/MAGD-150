let array1 = ["Number 1", "Number 2", "Number 3", "Number 4", "Number 5", "Number 6"];
let array2 = [];
let array3 = [];

function setup() {
  createCanvas(400, 400);
  background(220);

  for (let i = 0; i < 5; i++) 
{
    let num = floor(random(array1.length))
    array2.push(array1[num])
    array1.splice(num, 1)
 }

  array3 = array1.concat(array2)

  console.log(array1);
  console.log(array2);
  console.log(array3);
  let random1 = random(array1);
  let random2 = random(array2);
  let random3 = random(array3);

  textSize(14);
  fill(0);
  text("Array 1: " + array1.join(", "), 10, 40);
  text("Array 2: " + array2.join(", "), 10, 80);
  text("Random 1: " + random1, 10, 140);
  text("Random 2: " + random2, 10, 180);
  text("Random 1 & 2: " + random3, 10, 220);
}